/*--------------------------------------------------------/
    Code fait par :
    Lienhard Alexia
    et
    Smiljkovic Marko
/--------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

#include "module1.h"

void main(int argc, char *argv[]) {

	recuperation_donnees(argc, argv);

	//return 0;
}
