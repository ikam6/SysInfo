#ifndef COMMON_H
#define COMMON_H

void die(char *issue);
int copy(int from, int to);


#endif /* COMMON_H */
