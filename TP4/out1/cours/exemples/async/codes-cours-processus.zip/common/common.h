#ifndef _COMMON_H
#define _COMMON_H

#include <stdlib.h>
#include <stdio.h>

void OnError(const char *str)
{
	perror(str);
	exit(EXIT_FAILURE);
}



#endif