#include "../common/common.h"
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define MALLOC_SIZE 0x10 //en octets
#define STACK_ALLOC_SIZE 256*1024 //en octets

uint32_t nonInitData; //Variable globale non initialisée
uint32_t initData = 0x12; //Variable globale initialisée
char* ptChar = "Where is this pointed string?"; // ???
char tabChar[] = "Where is this char array?"; // ???

void useStack()
{
  //Augmentation de la pile
  char tab[STACK_ALLOC_SIZE];
  
  //Pause pour examiner le processus
  fgetc(stdin);
}

int main()
{
  //Décalaration de variables locales
  uint32_t localVar1, i;  
  void *pt_brk_before_alloc, *pt_brk_after_alloc; //pointeurs sur brk
  char *pt_malloc; //pointeur sur la zone allouée
  
  //Récuperer l'adresse du brk avant et après allocation de mémoire
  pt_brk_before_alloc = sbrk(0);
  pt_malloc = (char*) malloc(MALLOC_SIZE);
  pt_brk_after_alloc = sbrk(0);
  
  //Affichage de l'adresse de la fonction main dans le segment de code
  printf("--- code segment ---\n");
  printf("main function adress: %x\n", (unsigned int) &main);
  printf("Constant string adress: %x\n", (unsigned int) ptChar); //La chaine est constante donc dans .bss
  
  
  //Affichage des differente variable presentes dans le segment de donnée (dabord initialisées puis non initialisées)
  printf("--- data segment ---\n");
  printf("initData address: %x\n", (unsigned int) &initData);
  printf("Pointer to fixed string address: %x\n", (unsigned int) &ptChar); //Ce pointeur est alloué en donnée globale initialisée
  printf("Character array address: %x\n", (unsigned int) tabChar); //Le tableau est une variables (avec equivalence de pointeur) -> données initialisées
    printf("--\n");
  printf("nonInitData address: %x\n", (unsigned int) &nonInitData);  
  
  //Affichage des donnée du tas (brk avant et apres allocation de mémoire et pointeur sur donnée allouées)
  printf("--- Heap ---\n");  
  printf("Address allocated variable: %x\n", (unsigned int) pt_malloc);
  printf("Brk address before memory allocation: %x\n", (unsigned int) pt_brk_before_alloc);
  printf("Brk address after memory allocation: %x //all this memory is accessible although it was not explicitely allocated my malloc\n", (unsigned int) pt_brk_after_alloc);
  
  //Affichage des données locales affichées dans la piles
  printf("--- Stack ---\n");
  printf("First Local variable address: %x\n", (unsigned int) &localVar1);
  printf("Second Local variable address: %x\n", (unsigned int) &i);
  printf("pt_brk_before_alloc variable address: %x\n", (unsigned int) &pt_brk_before_alloc);
  printf("pt_brk_after_alloc variable address: %x\n", (unsigned int) &pt_brk_after_alloc);
  printf("pt_malloc variable address: %x\n", (unsigned int) &pt_malloc);
  printf("-------------\n");  
  
  //Pause pour examiner le processus
  fgetc(stdin);
  
  //utilisation de la pile et pause
  useStack();
    
  
  return EXIT_SUCCESS;
}

