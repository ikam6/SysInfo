#include <stdio.h>
#include <time.h>

//Lignes et colonne sont arbitraires
#define NB_LIGNES 500
#define NB_COLONNES 1000
#define NB_ITER 10000

int main(void)
{
	double tab2D[NB_LIGNES][NB_COLONNES];
	int i, j, l;
	clock_t debut = 0, fin = 0, tsol1 = 0, tsol2 = 0;
	
	for(l=0;l < NB_ITER;l++)
	{
		debut = clock();
		for(i=0;i<NB_LIGNES;i++)
			for(j=0;j<NB_COLONNES;j++)
				tab2D[i][j] = i+j/10.;
		fin = clock();
		tsol1 += fin - debut;

		debut = clock();
		for(j=0;j<NB_COLONNES;j++)
			for(i=0;i<NB_LIGNES;i++)
				tab2D[i][j] = i-j/10.;
		fin = clock();
		tsol2 += fin - debut;
	}
	printf("temps (premiere boucle - deuxieme boucle): %f - %f\n", (float) tsol1/NB_ITER, (float) tsol2/NB_ITER);
	return 0;
}
