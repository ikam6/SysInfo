#include <stdio.h>

#define TAILLE_MAX 3

void affiche_chaine(char*, int);

int main(void)
{
    int valeur1 = 1;
    char chaine[TAILLE_MAX] = {'a', 'b', '\0'};
    int valeur2 = 2;

    // Affiche l'état de la mémoire pour les variable ci-dessus
    printf("Valeur1:\tAdresse: %x\tValeur:%d\n", &valeur1, valeur1);
    affiche_chaine(chaine, TAILLE_MAX);
    printf("Valeur2:\tAdresse: %x\tValeur:%d\n", &valeur2, valeur2);

    // NE JAMAIS UTILISER GETS
    gets(chaine);

    // Affiche l'état de la mémoire pour les variable ci-dessus
    printf("Valeur1:\tAdresse: %x\tValeur:%d\n", &valeur1, valeur1);
    affiche_chaine(chaine, TAILLE_MAX);
    printf("Valeur2:\tAdresse: %x\tValeur:%d\n", &valeur2, valeur2); 
}

// Affiche l'addresse de chaque element de la chaine et le caractère
void affiche_chaine(char* chaine, int taille)
{
    for(int i=0; i<taille; i++)
        printf("Indice: %d\tAdresse: %x\tValeur: %c\n", i, &chaine[i], chaine[i]);
}
