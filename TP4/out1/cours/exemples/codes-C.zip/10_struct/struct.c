#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//D�claration de la structure
struct personne {
	char* nom;
	char* prenom;
	int age;
	};
	
struct personne unePersonne; // une instance de la structure en variable globale;

typedef struct el { //el est necessaire pour faire les declarations de pointeurs
	struct el *suivant;
	void* contenu;
	} element;

typedef element* listeChainee;


struct personne createPersonne(const char* nom, const char* prenom, int age) {
	int length;
	struct personne pers;
	
	length = strlen(nom) + 1; //+1 pour '\0'	
	pers.nom = calloc(length, sizeof(char));
	pers.prenom = calloc(strlen(prenom) + 1, sizeof(char));
	if((pers.nom == NULL) || (pers.prenom == NULL)) {
		printf("Erreur allocation m�moire\n");
		exit(1);
	}
	strcpy(pers.nom, nom);
	strcpy(pers.prenom, prenom);
	pers.age = age;		
	return pers;	
}

void affichePersonne(struct personne pers)
{
	printf("Nom: %s, Prenom: %s, Age: %d\n", pers.nom, pers.prenom, pers.age);
}

listeChainee initListeChaineeVide() {
	return NULL;
}

void addListe(listeChainee* liste, void* contenu) {

	//Creation d'un element et ajout dans la liste
	element *unEl = malloc(sizeof(element));
	unEl->contenu = contenu; //(*unEl).contenu se transforme en unEl->contenu
	unEl->suivant = *liste;	
	*liste = unEl;
}

void* removeListe(listeChainee *liste) {
	listeChainee tmp;	
	void* ret;
	
	ret = (*liste)->contenu;
	tmp = *liste;
	*liste = tmp->suivant;
	free(tmp); //Lib�ration de la m�moire	
	return ret;
}


int main(void)
{
	struct personne *ptPersonne;
	listeChainee maListe = initListeChaineeVide();
	
	//Une premi�re personne ajout�e
	unePersonne = createPersonne("Rodepeter", "Jessica", 36);
	affichePersonne(unePersonne);
	addListe(&maListe, &unePersonne);

	//Une seconde personne ajout�e
	if((ptPersonne = malloc(sizeof(struct personne))) == NULL)
	{
		printf("Erreur m�moire\n");
		return 1;
	}
	*ptPersonne = createPersonne("Page", "Marc", 8);
	affichePersonne(*ptPersonne);
	addListe(&maListe, ptPersonne);
	
	//Recup�re le contenu de la liste
	affichePersonne(*( (struct personne*) removeListe(&maListe)));
	affichePersonne(*( (struct personne*) removeListe(&maListe)));
	free(ptPersonne);
	
	return 0;
}