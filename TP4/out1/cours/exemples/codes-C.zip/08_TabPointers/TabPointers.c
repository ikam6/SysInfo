#include <stdio.h>

#define TAILLE_TAB 20

int afficheChaine(const char *tab)
{
	while(*tab) //Equivalent � while(*tab != '\0')
		putchar(*(tab++));
	puts("\n");
	
	//*tab = 'a'; //Erreur � la compilation !
}

int main(int argc, char* argv[]) //argc argv inutiles dans cet exemple
{
	char *chainePtr;
	char chaineTab[] = "Je suis bien content !";
	long long int *intPtr;
	long long int intTab[TAILLE_TAB];
	int i;

	//Initialisation du tableau d'entiers
	for(i=0;i<TAILLE_TAB;i++)
		intTab[i] = i+1;
	
	//Mettre les pointeurs sur les tableaux
	intPtr = intTab; //equivalent � &intTab[0];
	chainePtr = chaineTab;

	//Affiche la chaine pour une demonstration de const
	afficheChaine(chainePtr);
	
	//Affichage des equivalences
	printf("Adresse intPtr: %x, adresse intTab: %x\n", intPtr, intTab);
	printf("Adresse chainePtr: %x, adresse chaineTab: %x\n", chainePtr, chaineTab);
	printf("Contenu chainPtr: %s, contenu chaineTab: %s\n", chainePtr, chaineTab);	
	for(i=0;i<TAILLE_TAB;i++)
		printf("%ld = %ld\n", *(intPtr+i), intTab[i]);
	
	//Une difference
	printf("Taille pointeur: %d, Taille tableau : %d\n", sizeof(intPtr), sizeof(intTab));
	
	//Affiche la chaine pour une demonstration de const
	afficheChaine(chainePtr);
}
