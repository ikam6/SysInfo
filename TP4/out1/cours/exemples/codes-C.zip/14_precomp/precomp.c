#include <stdio.h>
#include <string.h>
#include "precomp.h"


int main(void)
{
	char c, string[] = STRING; //STRING doit etre definie lors de la compilation
	printf("defined STRING: %s\n", string);
	printf("defined VALUE: %d\n", INPUT); //INPUT doit etre definie lors de la compilation	
	printf("Le plus petit nombre est: %d\n", min(INPUT, 5));
	printf("Votre systeme est: %s\n", SYS);
	if((c = getCharSep()) != -1)
	{
		printf("Separateur de charactere: %c\n", c);
		return 0;
	}	
	else
		return 1;
}

/*************************************************************
Determine quel est le caract�re de s�paration des r�pertoires
qui correspond au syst�me d'exploitation sur lequel le programme
as �t� compil�.
IN: vide
OUT: retourne un caract�re repr�sentant le s�parateur de dossiers.
retourne -1 si il n'as pas pu �tre identifi� (syst�me non identifi�)
**************************************************************/
char getCharSep()
{
#ifdef __unix__
	return '/';
#elif defined _WIN32
	return '\\';
#elif defined __APPLE__
	return '/';
#else
	return -1;
#endif
}


