#ifndef _PRECOMP_H //Evite l'inclusion infinie
#define _PRECOMP_H


#define USUAL 10 //Déjà vu
#define WHY //on peut aussi declarer des define sans valeur

//Défintion de macro:
//Notez que ? et : sont sont utilisable dans le code
//pour remplacer les if
#define COMPUTE ((INPUT) / (USUAL)) //INPUT has to be defined
#define min(a,b) (((a) < (b)) ? (a) : (b))

//Define a constant with the system name
#ifdef __unix__
#define SYS "Unix"
#elif defined _WIN32
#define SYS "Windows"
#elif defined __APPLE__
#define SYS "Mac"
#else
#define SYS "Unknown"
#endif

/****************** User interface *********************/

/*************************************************************
Determine quel est le caractère de séparation des répertoires
qui correspond au système d'exploitation sur lequel le programme
as été compilé.
IN: vide
OUT: retourne un caractère représentant le séparateur de dossiers.
retourne -1 si il n'as pas pu être identifié (système non identifié)
**************************************************************/
char getCharSep();

#endif //#def _PRECOMP_H
