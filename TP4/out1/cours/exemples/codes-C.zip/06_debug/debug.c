#include <stdio.h>
#include <stdlib.h>

int sumn(int);

int main(void)
{
	char input[2];
	printf("Sum of 100 first numbers = %d\n", sumn(100));
	printf("Please enter a integer : ");
	gets(input);
	printf("For your input the result is = %d\n", sumn(atoi(input)));
}

//sum the first N numbers
int sumn(int n)
{
	int i = 0, total = 0;

	while(1)
	{
		if (i = n)
			break;
		else
			total += i++;
	}
	return total;
}
