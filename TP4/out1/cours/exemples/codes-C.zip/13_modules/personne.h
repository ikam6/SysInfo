/*D�claration de la structure*/
struct personne {
	char* nom;
	char* prenom;
	int age;
	};


/*********************** Interface utilisateur ****************************/
struct personne createPersonne(const char* nom, const char* prenom, int age);
void affichePersonne(struct personne pers);
