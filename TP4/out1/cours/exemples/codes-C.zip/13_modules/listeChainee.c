#include <stdlib.h>
#include "listeChainee.h"

/* Declaration dans le .c pour une utilisation priv�e */
typedef struct el { /* el est necessaire pour faire les declarations de pointeurs */
	struct el *suivant;
	void* contenu;
} element;


/************************************************************
                Private functions
************************************************************/

// Retourne l'adresse du dernier element de 'liste' sous forme de listeChainee
// Retourne NULL si la liste est vide
static listeChainee findLastEl(listeChainee liste)
{
    if(liste == NULL)
        return NULL;

    while(liste->suivant != NULL)
        liste = liste->suivant;
    return liste;
}

// Cree et alloue la memoire pour un element de liste
//  IN:
//      contenu: pointeur sur du contenu a mettre dans l'element. C'est l'utilisateur
//               qui doit gerer le contenu (liberation memoire par exemple)
//      suivant: sur quoi pointera notre nouvele element
//  OUT:
//      retourne un pointeur sur l'element
static element* createElement(void *contenu, element* suivant)
{
	element *unEl = malloc(sizeof(element));
    if (unEl != NULL)
    {
        unEl->contenu = contenu; /* (*unEl).contenu se transforme en unEl->contenu */
        unEl->suivant = suivant;
    }
    return unEl;
}

/************************************************************
                User interface (Public)
************************************************************/

// Initialise une liste chainee Vide. Cette fonction doit toujours utilisee pour
// creer une listeChainee
// ex: ListeChainee maListe = initListeChaineeVide();
listeChainee initListeChaineeVide()
{
	return NULL;
}


// Test si 'liste' est vide
// retour 0 si non et une autre valeur si oui
int isListeChaineeVide(listeChainee liste)
{
    return liste == NULL;        
}


// Ajoute un contenu en debut de liste
// IN:
//      contenu: pointeur sur du contenu a mettre dans la liste. C'est l'utilisateur
//               qui doit gerer le contenu (liberation memoire par exemple)
// OUT:
//      liste: une liste ou ajouter le contenu. La liste sera modifiee, sauf si un nouvel
//             element n'a pas pu �tre alloue.
// TODO: retourner un code d'erreur si le contenu n'est pas ajoute
void addListe(listeChainee* liste, void* contenu) {

	/* Creation d'un element et ajout dans la liste */
    element* unEl = createElement(contenu, *liste);
    if(unEl != NULL)
    	*liste = unEl;
}


// Ajoute un contenu en fin de liste
// IN:
//      contenu: pointeur sur du contenu a mettre dans la liste. C'est l'utilisateur
//               qui doit gerer le contenu (liberation memoire par exemple)
// OUT:
//      liste: une liste ou ajouter le contenu. La liste sera modifiee, sauf si un nouvel
//             element n'a pas pu �tre alloue.
// TODO: retourner un code d'erreur si le contenu n'est pas ajoute
void addEndListe(listeChainee* liste, void*contenu)
{
    element* unEl = createElement(contenu, NULL);
    if(unEl != NULL)
    {
        listeChainee endListe = findLastEl(*liste);
        if(endListe == NULL) //La liste est vide
            *liste = unEl;
        else
        	endListe->suivant = unEl;
    }
}


// Suprime et retourne un contenu de la liste
// OUT:
//      liste: la liste dont le premier contenu a ete retire
//      retourne: un pointeur sur le contenu ou NULL si la liste est vide.
//                C'est l'utilisateur qui doit gerer le contenu (liberation memoire par exemple).
void* removeListe(listeChainee *liste) {
	listeChainee tmp;	
	void* ret;
    
    // Gere une liste vide
    if(*liste == NULL)
        return NULL;
	
    //Sinon on retourne le contenu et on libere l'element
	ret = (*liste)->contenu;
	tmp = *liste;
	*liste = tmp->suivant;
	free(tmp); /*Lib�ration de m�moire de l'element*/
	return ret;
}
