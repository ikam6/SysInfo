/* Cela est autoris� si la structure est d�finie plus loin */
typedef struct el* listeChainee;


/********************** interface utilisateur *******************/

// Initialise une liste chainee Vide. Cette fonction doit toujours utilisee pour
// creer une listeChainee
// ex: ListeChainee maListe = initListeChaineeVide();
listeChainee initListeChaineeVide();

// Test si 'liste' est vide
// retour 0 si non et une autre valeur si oui
int isListeChaineeVide(listeChainee liste);

// Ajoute un contenu en debut de liste
// IN:
//      contenu: pointeur sur du contenu a mettre dans la liste. C'est l'utilisateur
//               qui doit gerer le contenu (liberation memoire par exemple)
// OUT:
//      liste: une liste ou ajouter le contenu. La liste sera modifiee, sauf si un nouvel
//             element n'a pas pu �tre alloue.
void addListe(listeChainee* liste, void* contenu);


// Ajoute un contenu en fin de liste
// IN:
//      contenu: pointeur sur du contenu a mettre dans la liste. C'est l'utilisateur
//               qui doit gerer le contenu (liberation memoire par exemple)
// OUT:
//      liste: une liste ou ajouter le contenu. La liste sera modifiee, sauf si un nouvel
//             element n'a pas pu �tre alloue.
void addEndListe(listeChainee* liste, void*contenu);


// Suprime et retourne un contenu de la liste
// OUT:
//      liste: la liste dont le premier contenu a ete retire
//      retourne: un pointeur sur le contenu ou NULL si la liste est vide.
//                C'est l'utilisateur qui doit gerer le contenu (liberation memoire par exemple).
void* removeListe(listeChainee *liste);
