#include <stdio.h>
#include <stdlib.h>
#include "listeChainee.h"
#include "personne.h"
	
int main(void)
{
	struct personne unePersonne;
	struct personne *ptPersonne;
	listeChainee maListe = initListeChaineeVide();

	/* Une premi�re personne ajout�e */
	unePersonne = createPersonne("Rodepeter", "Jessica", 36);
	affichePersonne(unePersonne);
	addListe(&maListe, &unePersonne);

	/* Une seconde personne ajout�e */
	if((ptPersonne = malloc(sizeof(struct personne))) == NULL)
	{
		printf("Erreur m�moire\n");
		return 1;
	}
	*ptPersonne = createPersonne("Page", "Marc", 8);
	affichePersonne(*ptPersonne);
	addListe(&maListe, ptPersonne);
	

	/* Une troisi�me personne ajout�e en FIN de liste*/
	if((ptPersonne = malloc(sizeof(struct personne))) == NULL)
	{
		printf("Erreur m�moire\n");
		return 1;
	}
	*ptPersonne = createPersonne("LutteFinale", "Sheila", 78);
	affichePersonne(*ptPersonne);
	addEndListe(&maListe, ptPersonne);

	/* Recup�re le contenu de la liste et on la vide (+ lib�ration de m�moire */
    printf("\nOn affiche le contenu de la liste:\n");
    while(!isListeChaineeVide(maListe))
    {
        ptPersonne = removeListe(&maListe);
	    affichePersonne(*ptPersonne);
        if(ptPersonne != &unePersonne) //Ne pas liberer la m�moire de la variable unePersonne (allou�e sur la pile)
            free(ptPersonne);
    }
	
	return 0;
}
