#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	int i, sum = 0;

	if(argc != 0)
		printf("Le nom du programme est: %s\n", argv[0]);
	if(argc > 1)
	{
		//Sum the inputs
		for(i=1;i < argc; i++)
		{
			//Affiche le paramètre traité
			printf("Param %d: %s\n", i, argv[i]);

			//Convert the parameter to a number and sum it
			sum += atoi(argv[i]);
		}
	}

	return sum;
}
