#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	float *dynFloat = NULL;
	char *buffer = NULL;
	int taille;
	
	printf("Entrer la taille desiree: ");
	scanf("%d", &taille); 
	
	//malloc et calloc retournent void*, il est donc n�c�ssaire de 
	//faire un cast dans le bon type du pointeur
	dynFloat = malloc(taille*sizeof(float));
	buffer = calloc(taille, sizeof(char));
	
	//Erreur lors de l'allocation
	if((dynFloat == NULL) || (buffer == NULL))
	{
		printf("Erreur: impossible d'allouer la memoire necessaire.\n");
		free(buffer); //Ne fait rien si == NULL
		free(dynFloat);
		return 1; //ou exit(1)
	}

	*buffer = 'H'; *(buffer+1) = 'A', *(buffer+2) = 'L';
	printf("Contenu buffer: %s\n", buffer); //Ok car mise � zero
	printf("Contenu float: %f\n", *(dynFloat+3)); //valeur ind�finie
	
	//Lib�ration de la m�moire
	free(buffer);
	free(dynFloat);
	return 0;
}
