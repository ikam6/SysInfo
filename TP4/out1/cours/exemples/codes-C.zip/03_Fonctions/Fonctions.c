#include <stdio.h>

/*
Calcul le pourcentage du nombre "valeur" par rapport � "centPourcent"
IN:
	valeur: contient la valeur a mettre en rapport pour le calcul
			du pourcentage. Une fois la fonction ex�cut�e valeur contient
			le pourcentage.
	centPourcent: valeur par rapport � laquelle le pourcentage est calcul�
OUT:
	retourne -1 si une valeur d'entr�e n'est pas valide 0 sinon
	valeur contient la valeur exprim�e en pourcentage par rapport a centPourcent
*/
int versPourcentage(float *valeur, float centPourcent)
{
	int err = 0;
	
	if( (centPourcent > 0) && (*valeur >= 0) && (centPourcent >= *valeur))
		*valeur = (*valeur / centPourcent)*100;
	else
		err = -1;
	
	return err;
}

int main(void)
{
	int valeur = 10, max = 30;
	
	float pourcentage = valeur;
	if(versPourcentage(&pourcentage, max) < 0)
	{
		printf("Error: impossible de calculer le pourcentage\n");
		return -1;
	}
	printf("Poucentage: %f\n", pourcentage);
	return 0;
}