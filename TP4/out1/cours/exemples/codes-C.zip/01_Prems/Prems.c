#include <stdio.h>
#include <math.h>

#define PI 3.14159265359

double surface(float x)
{
	return x * x * PI;
}
/* La fonction main est toujours la premi�re fonction du programme � �tre
appell�e lors que l'execution*/
int main(void)
{
	int input, i;

	//la fonction printf affiche quelque chose
	printf("Veuillez entrer une valeur: ");
	scanf("%d", &input); //la fonction scanf lit l'entr�e utilisateur
	for(i=1; i < input; i++)
	{
		float per = surface(i);
		printf("Le resultat pour %d est: %f\n", i, per);
	}

	return 0;
}
