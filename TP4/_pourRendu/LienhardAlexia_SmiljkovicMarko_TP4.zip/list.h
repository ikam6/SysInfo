/*--------------------------------------------------------/
     Code fait par :
     Lienhard Alexia
     et
     Smiljkovic Marko
/--------------------------------------------------------*/
void list (const char *dirName);
