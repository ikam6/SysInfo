/*--------------------------------------------------------/
     Code fait par :
     Lienhard Alexia
     et
     Smiljkovic Marko
/--------------------------------------------------------*/
int printInfo(const char *nameDir, const char *nameFile);
