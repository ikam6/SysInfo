/*--------------------------------------------------------/
    Code fait par :
    Lienhard Alexia
    et
    Smiljkovic Marko
/--------------------------------------------------------*/

void builtinExit(char *line);
void builtinCd(char* argv[], char *cwd);
